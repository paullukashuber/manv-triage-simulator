const API_BASE = import.meta.env.VITE_API_URL || "/api";

async function request(path, options = {}) {
  const res = await fetch(`${API_BASE}${path}`, {
    headers: { "Content-Type": "application/json", ...options.headers },
    ...options,
  });
  const data = await res.json().catch(() => null);
  if (!res.ok) {
    const message = data?.error || data?.errors?.join(", ") || `HTTP ${res.status}`;
    throw new Error(message);
  }
  return data;
}

export function submitScenario(scenario) {
  return request("/scenarios", { method: "POST", body: JSON.stringify(scenario) });
}

export function fetchSubmissions(params = {}) {
  const query = new URLSearchParams(params).toString();
  return request(`/admin/scenarios${query ? `?${query}` : ""}`);
}

export function updateSubmission(id, data) {
  return request(`/admin/scenarios/${id}`, { method: "PATCH", body: JSON.stringify(data) });
}

export function deleteSubmission(id) {
  return request(`/admin/scenarios/${id}`, { method: "DELETE" });
}

export function exportSubmission(id) {
  return fetch(`${API_BASE}/admin/scenarios/${id}/export`).then((r) => r.text());
}
