import { useState, useCallback } from "react";
import { submitScenario } from "../utils/api";

const TRIAGE_STEPS = [
  { key: "tourniquet", label: "Lebensbedrohliche Extremitätenblutung?", hint: "Falls ja → Tourniquet! Beendet die Sichtung NICHT.", category: null, endsAssessment: false, badge: "C" },
  { key: "ambulatory", label: "Ist der Patient gehfähig?", hint: "Selbstständig gehen → PAK weiß, Sammelstelle.", category: "white", endsAssessment: true, badge: "?" },
  { key: "deathSigns", label: "Sichere Todeszeichen?", hint: "Totenstarre, Totenflecken, nicht vereinbare Verletzungen.", category: "dead", endsAssessment: true, badge: "†" },
  { key: "stridor", label: "Inhalationstrauma mit Stridor?", hint: "Pfeifendes Atemgeräusch nach Rauchgas-/Hitzeexposition.", category: "red", endsAssessment: true, badge: "A" },
  { key: "airwayBlocked", label: "Offenhalten Atemweg erforderlich?", hint: "Verlegter Atemweg, Gurgelgeräusche.", category: "red", endsAssessment: true, badge: "A" },
  { key: "abnormalBreathingRate", label: "Pathologische Atemfrequenz?", hint: "Erw: AF <10 oder >30 · Kind: AF <15 oder >40", category: "red", endsAssessment: true, badge: "B" },
  { key: "majorBleeding", label: "Lebensbedrohliche Blutung?", hint: "Massive, nicht kontrollierbare Blutung.", category: "red", endsAssessment: true, badge: "C" },
  { key: "noRadialPulse", label: "Kein Radialispuls tastbar?", hint: "10 Sek. Prüfung. Kein Puls ≙ RR <80mmHg.", category: "red", endsAssessment: true, badge: "C" },
  { key: "unresponsive", label: "Keine gezielte Reaktion auf Ansprache?", hint: "WASB < W.", category: "red", endsAssessment: true, badge: "D" },
];

const CATEGORY_LABELS = {
  red: "SK 1 – Sofortbehandlung",
  yellow: "SK 2 – Aufgeschobene Behandlung",
  white: "PAK weiß – Sammelstelle",
  dead: "Tot – Leichenschau erforderlich",
};

const CATEGORY_COLORS = {
  red: "var(--color-sk1)", yellow: "var(--color-sk2)",
  white: "var(--color-white)", dead: "var(--color-dead)",
};

function computeCategory(answers) {
  for (const step of TRIAGE_STEPS) {
    if (!step.endsAssessment) continue;
    if (answers[step.key]) return step.category;
  }
  return "yellow";
}

const emptyAnswers = Object.fromEntries(TRIAGE_STEPS.map((s) => [s.key, false]));

export default function SubmitScenario() {
  const [phase, setPhase] = useState("intro");
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [reasoning, setReasoning] = useState("");
  const [answers, setAnswers] = useState({ ...emptyAnswers });
  const [algoIdx, setAlgoIdx] = useState(0);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(false);

  const category = computeCategory(answers);
  const catColor = CATEGORY_COLORS[category];
  const catTextColor = category === "yellow" || category === "white" ? "var(--color-bg)" : "#fff";

  const handleAlgoAnswer = useCallback((val) => {
    const step = TRIAGE_STEPS[algoIdx];
    const next = { ...answers, [step.key]: val };
    setAnswers(next);
    if (val && step.endsAssessment) { setPhase("reasoning"); return; }
    if (algoIdx < TRIAGE_STEPS.length - 1) setAlgoIdx(algoIdx + 1);
    else setPhase("reasoning");
  }, [algoIdx, answers]);

  const handleSubmit = async () => {
    setSubmitting(true); setError(null);
    try {
      await submitScenario({
        description: description.trim(), correctAnswers: answers,
        correctCategory: category, reasoning: reasoning.trim(),
        submitterName: name.trim() || null,
      });
      setSuccess(true); setPhase("done");
    } catch (err) { setError(err.message); }
    finally { setSubmitting(false); }
  };

  const reset = () => {
    setPhase("intro"); setName(""); setDescription(""); setReasoning("");
    setAnswers({ ...emptyAnswers }); setAlgoIdx(0); setError(null); setSuccess(false);
  };

  return (
    <>
      <div className="text-center mb-1">
        <span className="inline-block bg-[var(--color-accent-muted)] border border-[var(--color-accent)]/15 rounded-md px-2.5 py-0.5 text-[0.65rem] font-semibold text-[var(--color-accent)] tracking-wide mb-1.5">
          Szenario einreichen
        </span>
        <h1 className="text-xl font-bold">
          ManV <span className="text-[var(--color-sk1)]">Triage</span> Simulator
        </h1>
      </div>

      <div className="flex gap-1">
        {["intro", "patient", "algo", "reasoning", "done"].map((p, i) => (
          <div key={p} className="flex-1 h-1 rounded-full transition-colors duration-300"
            style={{ background: ["intro", "patient", "algo", "reasoning", "done"].indexOf(phase) >= i ? "var(--color-accent)" : "var(--color-bg-surface)" }} />
        ))}
      </div>

      {phase === "intro" && (
        <div className="bg-[var(--color-bg-card)] border border-[var(--color-border)] rounded-xl p-4 flex flex-col gap-3">
          <div className="bg-[var(--color-accent-muted)] border border-[var(--color-accent)]/15 rounded-lg px-3 py-2.5 text-[0.82rem] leading-snug">
            <strong className="text-[var(--color-accent)]">So funktioniert's:</strong><br />
            <span className="text-[var(--color-text-muted)]">
              Beschreibe einen Patienten, geh den Algorithmus durch, und dein Szenario wird automatisch gespeichert. Dauer: 2–3 Minuten.
            </span>
          </div>
          <div>
            <label className="text-[0.75rem] text-[var(--color-text-muted)] font-medium mb-1 block">Dein Name (optional)</label>
            <input value={name} onChange={(e) => setName(e.target.value)} placeholder="z.B. Max M."
              className="w-full bg-[var(--color-bg-surface)] border border-[var(--color-border)] rounded-lg px-3 py-2.5 text-[var(--color-text)] text-[0.9rem] outline-none" />
          </div>
          <button onClick={() => setPhase("patient")}
            className="w-full py-3 bg-[var(--color-accent)] text-[var(--color-bg)] font-bold rounded-lg active:scale-[0.97] transition-transform cursor-pointer">
            Los geht's →
          </button>
          <a href="/" className="text-center text-[0.75rem] text-[var(--color-text-dim)] hover:text-[var(--color-accent)]">← Zurück zum Simulator</a>
        </div>
      )}

      {phase === "patient" && (
        <div className="bg-[var(--color-bg-card)] border border-[var(--color-border)] rounded-xl p-4 flex flex-col gap-3">
          <div className="bg-[var(--color-accent-muted)] border border-[var(--color-accent)]/15 rounded-lg px-3 py-2 text-[0.78rem] text-[var(--color-text-muted)] leading-snug">
            Beschreibe den Patienten wie bei einem echten Einsatz: Alter, Geschlecht, Bewusstseinslage, sichtbare Verletzungen, Atmung, Puls.
          </div>
          <textarea value={description} onChange={(e) => setDescription(e.target.value)}
            placeholder="z.B.: 45-jähriger Mann, liegt am Boden, nicht ansprechbar. AF ca. 6/min. Keine sichtbaren äußeren Verletzungen."
            rows={5} className="w-full bg-[var(--color-bg-surface)] border border-[var(--color-border)] rounded-lg px-3 py-2.5 text-[var(--color-text)] text-[0.9rem] outline-none resize-y min-h-[120px]" />
          <div className="flex gap-2">
            <button onClick={() => setPhase("intro")}
              className="flex-1 py-3 bg-[var(--color-bg-surface)] text-[var(--color-text)] border border-[var(--color-border)] font-bold rounded-lg cursor-pointer">← Zurück</button>
            <button onClick={() => { setAlgoIdx(0); setAnswers({ ...emptyAnswers }); setPhase("algo"); }}
              disabled={description.trim().length < 20}
              className="flex-[2] py-3 bg-[var(--color-accent)] text-[var(--color-bg)] font-bold rounded-lg active:scale-[0.97] transition-transform cursor-pointer disabled:opacity-40">
              Weiter →
            </button>
          </div>
        </div>
      )}

      {phase === "algo" && (
        <div className="bg-[var(--color-bg-card)] border border-[var(--color-border)] rounded-xl p-4 flex flex-col gap-3">
          <div className="flex justify-between text-[0.75rem] text-[var(--color-text-dim)]">
            <span>Schritt {algoIdx + 1} / {TRIAGE_STEPS.length}</span>
            <span className="bg-[var(--color-bg-surface)] border border-[var(--color-border)] rounded px-2 py-0.5 text-[0.65rem]">VOR-Sichtung</span>
          </div>
          <div className="bg-[var(--color-bg-surface)] rounded-lg px-3 py-2 text-[0.8rem] text-[var(--color-text-muted)] leading-snug border-l-[3px] border-[var(--color-accent)]">
            {description}
          </div>
          <div className="py-1">
            <div className="flex items-start gap-2.5">
              <div className="w-8 h-8 rounded-lg shrink-0 flex items-center justify-center text-sm font-bold bg-[var(--color-sk1)]/15 text-[var(--color-sk1)]">
                {TRIAGE_STEPS[algoIdx].badge}
              </div>
              <div>
                <p className="text-base font-bold leading-snug">{TRIAGE_STEPS[algoIdx].label}</p>
                <p className="text-[0.78rem] text-[var(--color-text-muted)] mt-1 leading-snug">{TRIAGE_STEPS[algoIdx].hint}</p>
              </div>
            </div>
          </div>
          <p className="text-[0.75rem] text-[var(--color-text-dim)] italic px-1">Bezogen auf deinen Patienten: Trifft dieser Befund zu?</p>
          <div className="flex gap-2.5">
            <button onClick={() => handleAlgoAnswer(true)}
              className="flex-1 py-3.5 bg-[var(--color-correct)] text-white font-bold text-base rounded-lg active:scale-[0.97] transition-transform cursor-pointer">Ja</button>
            <button onClick={() => handleAlgoAnswer(false)}
              className="flex-1 py-3.5 bg-[var(--color-wrong)] text-white font-bold text-base rounded-lg active:scale-[0.97] transition-transform cursor-pointer">Nein</button>
          </div>
        </div>
      )}

      {phase === "reasoning" && (
        <div className="bg-[var(--color-bg-card)] border border-[var(--color-border)] rounded-xl p-4 flex flex-col gap-3">
          <div className="text-center">
            <span className="text-[0.75rem] text-[var(--color-text-dim)]">Berechnete Kategorie</span>
            <div className="inline-block mt-1.5 px-4 py-1.5 rounded-lg font-bold text-[0.9rem]"
              style={{ background: catColor, color: catTextColor }}>
              {CATEGORY_LABELS[category]}
            </div>
          </div>
          <div className="bg-[var(--color-accent-muted)] border border-[var(--color-accent)]/15 rounded-lg px-3 py-2 text-[0.78rem] text-[var(--color-text-muted)] leading-snug">
            Erkläre kurz, warum der Patient in diese Kategorie fällt. Was ist der entscheidende Befund?
          </div>
          <textarea value={reasoning} onChange={(e) => setReasoning(e.target.value)}
            placeholder="z.B.: AF < 10/min bei Erwachsenen → pathologisch → SK 1" rows={3}
            className="w-full bg-[var(--color-bg-surface)] border border-[var(--color-border)] rounded-lg px-3 py-2.5 text-[var(--color-text)] text-[0.9rem] outline-none resize-y min-h-[80px]" />
          {error && (
            <div className="bg-[var(--color-sk1)]/10 border border-[var(--color-sk1)]/30 rounded-lg px-3 py-2 text-[0.8rem] text-[var(--color-sk1)]">{error}</div>
          )}
          <button onClick={handleSubmit} disabled={reasoning.trim().length < 10 || submitting}
            className="w-full py-3 bg-[var(--color-accent)] text-[var(--color-bg)] font-bold rounded-lg active:scale-[0.97] transition-transform cursor-pointer disabled:opacity-40">
            {submitting ? "Wird gespeichert..." : "Szenario einreichen"}
          </button>
        </div>
      )}

      {phase === "done" && success && (
        <div className="bg-[var(--color-bg-card)] border border-[var(--color-border)] rounded-xl p-4 flex flex-col gap-3 text-center">
          <div className="text-3xl">✓</div>
          <p className="text-base font-bold text-[var(--color-correct)]">Szenario eingereicht!</p>
          <p className="text-[0.82rem] text-[var(--color-text-muted)]">Danke für deinen Beitrag! Ein Ausbilder wird dein Szenario prüfen.</p>
          <div className="flex gap-2 mt-2">
            <button onClick={reset} className="flex-1 py-3 bg-[var(--color-accent)] text-[var(--color-bg)] font-bold rounded-lg cursor-pointer">Noch eins einreichen</button>
            <a href="/" className="flex-1 py-3 bg-[var(--color-bg-surface)] text-[var(--color-text)] border border-[var(--color-border)] font-bold rounded-lg text-center flex items-center justify-center">Zum Simulator</a>
          </div>
        </div>
      )}
    </>
  );
}
