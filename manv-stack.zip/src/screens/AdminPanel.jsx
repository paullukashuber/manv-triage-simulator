import { useState, useEffect, useCallback } from "react";
import { fetchSubmissions, updateSubmission, deleteSubmission, exportSubmission } from "../utils/api";

const STATUS_LABELS = { PENDING: "Ausstehend", APPROVED: "Freigegeben", REJECTED: "Abgelehnt" };
const STATUS_COLORS = { PENDING: "var(--color-sk2)", APPROVED: "var(--color-correct)", REJECTED: "var(--color-sk1)" };
const CATEGORY_LABELS = { red: "SK 1", yellow: "SK 2", white: "PAK weiß", dead: "Tot" };
const CATEGORY_BG = { red: "var(--color-sk1)", yellow: "var(--color-sk2)", white: "var(--color-white)", dead: "var(--color-dead)" };

export default function AdminPanel() {
  const [submissions, setSubmissions] = useState([]);
  const [counts, setCounts] = useState({});
  const [filter, setFilter] = useState("PENDING");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [expanded, setExpanded] = useState(null);
  const [exportCode, setExportCode] = useState(null);
  const [actionLoading, setActionLoading] = useState(null);

  const load = useCallback(async () => {
    setLoading(true); setError(null);
    try {
      const data = await fetchSubmissions({ status: filter });
      setSubmissions(data.submissions);
      setCounts(data.counts);
    } catch (err) { setError(err.message); }
    finally { setLoading(false); }
  }, [filter]);

  useEffect(() => { load(); }, [load]);

  const handleStatus = async (id, status) => {
    setActionLoading(id);
    try { await updateSubmission(id, { status }); await load(); setExpanded(null); }
    catch (err) { setError(err.message); }
    finally { setActionLoading(null); }
  };

  const handleDelete = async (id) => {
    if (!confirm("Szenario wirklich löschen?")) return;
    setActionLoading(id);
    try { await deleteSubmission(id); await load(); setExpanded(null); }
    catch (err) { setError(err.message); }
    finally { setActionLoading(null); }
  };

  const handleExport = async (id) => {
    try { const code = await exportSubmission(id); setExportCode({ id, code }); }
    catch (err) { setError(err.message); }
  };

  return (
    <>
      <div className="text-center mb-1">
        <span className="inline-block bg-[var(--color-sk1)]/10 border border-[var(--color-sk1)]/20 rounded-md px-2.5 py-0.5 text-[0.65rem] font-semibold text-[var(--color-sk1)] tracking-wide mb-1.5">Admin</span>
        <h1 className="text-xl font-bold">Szenario-Einreichungen</h1>
      </div>

      {/* Filter tabs */}
      <div className="flex gap-2">
        {["PENDING", "APPROVED", "REJECTED"].map((s) => (
          <button key={s} onClick={() => setFilter(s)}
            className="flex-1 rounded-lg p-2.5 text-center transition-colors cursor-pointer border"
            style={{
              background: filter === s ? "var(--color-bg-elevated)" : "var(--color-bg-card)",
              borderColor: filter === s ? "var(--color-accent)" : "var(--color-border)",
            }}>
            <div className="text-lg font-bold" style={{ color: STATUS_COLORS[s] }}>{counts[s] || 0}</div>
            <div className="text-[0.65rem] text-[var(--color-text-muted)]">{STATUS_LABELS[s]}</div>
          </button>
        ))}
      </div>

      {error && (
        <div className="bg-[var(--color-sk1)]/10 border border-[var(--color-sk1)]/30 rounded-lg px-3 py-2 text-[0.8rem] text-[var(--color-sk1)]">
          {error} <button onClick={() => setError(null)} className="ml-2 underline cursor-pointer">×</button>
        </div>
      )}

      {loading && <div className="text-center py-8 text-[var(--color-text-muted)] text-[0.85rem]">Lade...</div>}

      {!loading && submissions.length === 0 && (
        <div className="bg-[var(--color-bg-card)] border border-[var(--color-border)] rounded-xl p-6 text-center">
          <p className="text-[var(--color-text-muted)] text-[0.85rem]">Keine {STATUS_LABELS[filter].toLowerCase()}en Einreichungen.</p>
        </div>
      )}

      {!loading && submissions.map((sub) => (
        <div key={sub.id} className="bg-[var(--color-bg-card)] border border-[var(--color-border)] rounded-xl overflow-hidden">
          <button onClick={() => setExpanded(expanded === sub.id ? null : sub.id)}
            className="w-full px-4 py-3 flex items-center gap-3 text-left cursor-pointer hover:bg-[var(--color-bg-surface)] transition-colors">
            <span className="shrink-0 w-14 text-center px-1.5 py-0.5 rounded text-[0.65rem] font-bold"
              style={{ background: CATEGORY_BG[sub.correctCategory], color: sub.correctCategory === "yellow" || sub.correctCategory === "white" ? "var(--color-bg)" : "#fff" }}>
              {CATEGORY_LABELS[sub.correctCategory]}
            </span>
            <span className="flex-1 text-[0.82rem] text-[var(--color-text)] truncate">{sub.description}</span>
            <span className="text-[0.65rem] text-[var(--color-text-dim)] shrink-0">{new Date(sub.createdAt).toLocaleDateString("de-DE")}</span>
            <span className="text-[var(--color-text-dim)] text-[0.8rem] shrink-0">{expanded === sub.id ? "▾" : "▸"}</span>
          </button>

          {expanded === sub.id && (
            <div className="px-4 pb-4 flex flex-col gap-3 border-t border-[var(--color-border)]">
              <div className="pt-3">
                <div className="text-[0.7rem] text-[var(--color-text-dim)] mb-1">Patientenbeschreibung</div>
                <p className="text-[0.82rem] text-[var(--color-text)] leading-snug bg-[var(--color-bg-surface)] rounded-lg px-3 py-2">{sub.description}</p>
              </div>
              <div>
                <div className="text-[0.7rem] text-[var(--color-text-dim)] mb-1">Begründung</div>
                <p className="text-[0.82rem] text-[var(--color-text-muted)] leading-snug bg-[var(--color-bg-surface)] rounded-lg px-3 py-2">{sub.reasoning}</p>
              </div>
              <div>
                <div className="text-[0.7rem] text-[var(--color-text-dim)] mb-1">Algorithmus-Antworten</div>
                <div className="grid grid-cols-3 gap-1">
                  {Object.entries(sub.correctAnswers).map(([key, val]) => (
                    <div key={key} className="text-[0.65rem] px-2 py-1 rounded bg-[var(--color-bg-surface)] flex justify-between">
                      <span className="text-[var(--color-text-dim)] truncate">{key}</span>
                      <span className="font-bold ml-1" style={{ color: val ? "var(--color-correct)" : "var(--color-text-dim)" }}>{val ? "Ja" : "–"}</span>
                    </div>
                  ))}
                </div>
              </div>
              {sub.submitterName && (
                <div className="text-[0.75rem] text-[var(--color-text-dim)]">
                  Eingereicht von: <strong className="text-[var(--color-text-muted)]">{sub.submitterName}</strong>
                </div>
              )}

              {exportCode?.id === sub.id && (
                <div className="relative">
                  <pre className="bg-[#0d0e10] border border-[var(--color-border)] rounded-lg px-3 py-2.5 text-[0.7rem] text-[var(--color-accent)] overflow-auto max-h-48 whitespace-pre-wrap">{exportCode.code}</pre>
                  <button onClick={() => navigator.clipboard.writeText(exportCode.code)}
                    className="absolute top-2 right-2 bg-[var(--color-bg-surface)] border border-[var(--color-border)] rounded px-2 py-0.5 text-[0.65rem] text-[var(--color-text-muted)] cursor-pointer hover:text-[var(--color-accent)]">Kopieren</button>
                </div>
              )}

              <div className="flex gap-2 flex-wrap">
                {sub.status !== "APPROVED" && (
                  <button onClick={() => handleStatus(sub.id, "APPROVED")} disabled={actionLoading === sub.id}
                    className="px-3 py-1.5 bg-[var(--color-correct)] text-white text-[0.75rem] font-bold rounded-lg cursor-pointer disabled:opacity-50">Freigeben</button>
                )}
                {sub.status !== "REJECTED" && (
                  <button onClick={() => handleStatus(sub.id, "REJECTED")} disabled={actionLoading === sub.id}
                    className="px-3 py-1.5 bg-[var(--color-sk1)] text-white text-[0.75rem] font-bold rounded-lg cursor-pointer disabled:opacity-50">Ablehnen</button>
                )}
                {sub.status !== "PENDING" && (
                  <button onClick={() => handleStatus(sub.id, "PENDING")} disabled={actionLoading === sub.id}
                    className="px-3 py-1.5 bg-[var(--color-bg-surface)] text-[var(--color-text)] border border-[var(--color-border)] text-[0.75rem] font-bold rounded-lg cursor-pointer disabled:opacity-50">Zurücksetzen</button>
                )}
                <button onClick={() => handleExport(sub.id)}
                  className="px-3 py-1.5 bg-[var(--color-accent)] text-[var(--color-bg)] text-[0.75rem] font-bold rounded-lg cursor-pointer">JS Export</button>
                <button onClick={() => handleDelete(sub.id)} disabled={actionLoading === sub.id}
                  className="px-3 py-1.5 bg-[var(--color-bg-surface)] text-[var(--color-text-dim)] border border-[var(--color-border)] text-[0.75rem] rounded-lg cursor-pointer hover:text-[var(--color-sk1)] disabled:opacity-50">Löschen</button>
              </div>
            </div>
          )}
        </div>
      ))}

      <div className="flex gap-2 mt-2">
        <a href="/" className="flex-1 py-2.5 bg-[var(--color-bg-surface)] text-[var(--color-text)] border border-[var(--color-border)] font-bold text-[0.82rem] rounded-lg text-center">← Simulator</a>
        <button onClick={load} className="flex-1 py-2.5 bg-[var(--color-accent)] text-[var(--color-bg)] font-bold text-[0.82rem] rounded-lg cursor-pointer">Aktualisieren</button>
      </div>
    </>
  );
}
