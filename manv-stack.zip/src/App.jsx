import { useState, useEffect } from "react";
import { useSimulator } from "./hooks/useSimulator";
import { SCREENS } from "./utils/constants";
import PrototypeModal from "./components/PrototypeModal";
import StartScreen from "./screens/StartScreen";
import ScenarioIntro from "./screens/ScenarioIntro";
import TriageStep from "./screens/TriageStep";
import ScenarioResult from "./screens/ScenarioResult";
import Summary from "./screens/Summary";
import SubmitScenario from "./screens/SubmitScenario";
import AdminPanel from "./screens/AdminPanel";

function useRoute() {
  const [path, setPath] = useState(window.location.pathname);
  useEffect(() => {
    const onPop = () => setPath(window.location.pathname);
    window.addEventListener("popstate", onPop);
    return () => window.removeEventListener("popstate", onPop);
  }, []);
  return path;
}

function normalizePath(path) {
  const base = import.meta.env.BASE_URL || "/";
  if (base !== "/" && path.startsWith(base))
    return path.slice(base.length - 1) || "/";
  return path;
}

function SimulatorApp() {
  const simulator = useSimulator();
  const { screen } = simulator.state;
  const screens = {
    [SCREENS.START]: StartScreen,
    [SCREENS.SCENARIO_INTRO]: ScenarioIntro,
    [SCREENS.TRIAGE_STEP]: TriageStep,
    [SCREENS.SCENARIO_RESULT]: ScenarioResult,
    [SCREENS.SUMMARY]: Summary,
  };
  const ScreenComponent = screens[screen] || StartScreen;
  return (
    <>
      <PrototypeModal />
      <ScreenComponent simulator={simulator} />
    </>
  );
}

export default function App() {
  const rawPath = useRoute();
  const path = normalizePath(rawPath);

  let content;
  if (path === "/submit") content = <SubmitScenario />;
  else if (path.startsWith("/admin")) content = <AdminPanel />;
  else content = <SimulatorApp />;

  return (
    <div className="min-h-dvh flex flex-col items-center">
      <div className="w-full max-w-[480px] flex flex-col p-4 pb-0 gap-3">
        {content}
      </div>
    </div>
  );
}
