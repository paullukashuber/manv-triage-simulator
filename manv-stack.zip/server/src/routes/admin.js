import { Router } from "express";
import { PrismaClient } from "@prisma/client";
import { requireAuth } from "../middleware/auth.js";

const prisma = new PrismaClient();
const router = Router();

router.use(requireAuth);

router.get("/scenarios", async (req, res) => {
  try {
    const { status } = req.query;
    const where = {};
    if (status && ["PENDING", "APPROVED", "REJECTED"].includes(status))
      where.status = status;

    const submissions = await prisma.scenarioSubmission.findMany({
      where, orderBy: { createdAt: "desc" },
    });
    const counts = await prisma.scenarioSubmission.groupBy({
      by: ["status"], _count: true,
    });
    res.json({
      submissions,
      counts: Object.fromEntries(counts.map((c) => [c.status, c._count])),
    });
  } catch (err) {
    console.error("List error:", err);
    res.status(500).json({ error: "Fehler beim Laden." });
  }
});

router.get("/scenarios/:id", async (req, res) => {
  try {
    const s = await prisma.scenarioSubmission.findUnique({
      where: { id: parseInt(req.params.id) },
    });
    if (!s) return res.status(404).json({ error: "Nicht gefunden." });
    res.json(s);
  } catch (err) {
    res.status(500).json({ error: "Fehler beim Laden." });
  }
});

router.patch("/scenarios/:id", async (req, res) => {
  try {
    const { status, reviewNotes } = req.body;
    if (!["APPROVED", "REJECTED", "PENDING"].includes(status))
      return res.status(400).json({ error: "Ungültiger Status." });

    const s = await prisma.scenarioSubmission.update({
      where: { id: parseInt(req.params.id) },
      data: {
        status,
        reviewNotes: reviewNotes || null,
        reviewedAt: status !== "PENDING" ? new Date() : null,
        reviewedBy: req.adminUser || null,
      },
    });
    res.json(s);
  } catch (err) {
    res.status(500).json({ error: "Fehler beim Aktualisieren." });
  }
});

router.delete("/scenarios/:id", async (req, res) => {
  try {
    await prisma.scenarioSubmission.delete({
      where: { id: parseInt(req.params.id) },
    });
    res.json({ message: "Gelöscht." });
  } catch (err) {
    res.status(500).json({ error: "Fehler beim Löschen." });
  }
});

router.get("/scenarios/:id/export", async (req, res) => {
  try {
    const s = await prisma.scenarioSubmission.findUnique({
      where: { id: parseInt(req.params.id) },
    });
    if (!s) return res.status(404).json({ error: "Nicht gefunden." });

    const a = s.correctAnswers;
    const code = `  {
    id: NEW_ID,
    description:\n      ${JSON.stringify(s.description)},
    correctAnswers: {
      tourniquet: ${a.tourniquet}, ambulatory: ${a.ambulatory},
      deathSigns: ${a.deathSigns}, stridor: ${a.stridor},
      airwayBlocked: ${a.airwayBlocked}, abnormalBreathingRate: ${a.abnormalBreathingRate},
      majorBleeding: ${a.majorBleeding}, noRadialPulse: ${a.noRadialPulse},
      unresponsive: ${a.unresponsive},
    },
    correctCategory: ${JSON.stringify(s.correctCategory)},
    reasoning:\n      ${JSON.stringify(s.reasoning)},
  },`;
    res.type("text/plain").send(code);
  } catch (err) {
    res.status(500).json({ error: "Fehler beim Export." });
  }
});

export { router as adminRoutes };
