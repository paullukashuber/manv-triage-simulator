import { Router } from "express";
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();
const router = Router();

const VALID_CATEGORIES = ["red", "yellow", "white", "dead"];
const REQUIRED_ANSWER_KEYS = [
  "tourniquet", "ambulatory", "deathSigns", "stridor",
  "airwayBlocked", "abnormalBreathingRate", "majorBleeding",
  "noRadialPulse", "unresponsive",
];

function validateSubmission(body) {
  const errors = [];
  if (!body.description || body.description.trim().length < 20)
    errors.push("Patientenbeschreibung muss mindestens 20 Zeichen lang sein.");
  if (body.description && body.description.length > 2000)
    errors.push("Patientenbeschreibung darf maximal 2000 Zeichen lang sein.");
  if (!body.correctCategory || !VALID_CATEGORIES.includes(body.correctCategory))
    errors.push("Ungültige Kategorie.");
  if (!body.correctAnswers || typeof body.correctAnswers !== "object") {
    errors.push("Algorithmus-Antworten fehlen.");
  } else {
    for (const key of REQUIRED_ANSWER_KEYS) {
      if (typeof body.correctAnswers[key] !== "boolean")
        errors.push(`Antwort für "${key}" fehlt oder ist kein Boolean.`);
    }
  }
  if (!body.reasoning || body.reasoning.trim().length < 10)
    errors.push("Begründung muss mindestens 10 Zeichen lang sein.");
  if (body.reasoning && body.reasoning.length > 1000)
    errors.push("Begründung darf maximal 1000 Zeichen lang sein.");
  return errors;
}

router.post("/", async (req, res) => {
  try {
    const errors = validateSubmission(req.body);
    if (errors.length > 0) return res.status(400).json({ errors });

    const submission = await prisma.scenarioSubmission.create({
      data: {
        description: req.body.description.trim(),
        correctAnswers: req.body.correctAnswers,
        correctCategory: req.body.correctCategory,
        reasoning: req.body.reasoning.trim(),
        submitterName: req.body.submitterName?.trim() || null,
      },
    });

    res.status(201).json({
      message: "Szenario erfolgreich eingereicht!",
      id: submission.id,
    });
  } catch (err) {
    console.error("Submission error:", err);
    res.status(500).json({ error: "Fehler beim Speichern." });
  }
});

export { router as scenarioRoutes };
