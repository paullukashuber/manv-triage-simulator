/**
 * Authentik forward auth middleware.
 * Nginx sends X-Authentik-Username header for authenticated requests.
 * This is a safety net — Nginx blocks unauthed requests before they arrive.
 */
export function requireAuth(req, res, next) {
  const username = req.headers["x-authentik-username"] || req.headers["x-forwarded-user"];
  if (!username) return res.status(401).json({ error: "Nicht autorisiert." });
  req.adminUser = username;
  req.adminEmail = req.headers["x-authentik-email"] || null;
  next();
}
