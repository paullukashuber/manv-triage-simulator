import express from "express";
import cors from "cors";
import helmet from "helmet";
import { rateLimit } from "express-rate-limit";
import { scenarioRoutes } from "./routes/scenarios.js";
import { adminRoutes } from "./routes/admin.js";

const app = express();
const PORT = process.env.PORT || 3001;

app.use(helmet());
app.use(cors());
app.use(express.json({ limit: "100kb" }));

const submitLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  message: { error: "Zu viele Einreichungen. Bitte warte 15 Minuten." },
});

app.get("/api/health", (_req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

app.use("/api/scenarios", submitLimiter, scenarioRoutes);
app.use("/api/admin", adminRoutes);

app.use((err, _req, res, _next) => {
  console.error("Unhandled error:", err);
  res.status(500).json({ error: "Interner Serverfehler" });
});

app.listen(PORT, () => {
  console.log(`ManV API running on port ${PORT}`);
});
