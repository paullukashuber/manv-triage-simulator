CREATE TYPE "SubmissionStatus" AS ENUM ('PENDING', 'APPROVED', 'REJECTED');

CREATE TABLE "scenario_submissions" (
    "id" SERIAL NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,
    "submitter_name" TEXT,
    "description" TEXT NOT NULL,
    "correct_answers" JSONB NOT NULL,
    "correct_category" TEXT NOT NULL,
    "reasoning" TEXT NOT NULL,
    "status" "SubmissionStatus" NOT NULL DEFAULT 'PENDING',
    "reviewed_at" TIMESTAMP(3),
    "reviewed_by" TEXT,
    "review_notes" TEXT,
    CONSTRAINT "scenario_submissions_pkey" PRIMARY KEY ("id")
);
